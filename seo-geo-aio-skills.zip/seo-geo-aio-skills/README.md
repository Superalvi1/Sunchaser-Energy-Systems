# SEO / GEO / AIO Skills Bundle

39 skills, exported 2026-11-26. Each folder holds SKILL.md plus its reference files.

| Folder | Skill | Description |
|---|---|---|
| core-seo | seo-audit | "Run a full-site SEO audit and return a scored, prioritized report. Use only for site-wide checks; use seo-page for one URL or seo-technical for a technical-only review." |
| core-seo | seo-backlinks | "Analyze a site's backlink profile, anchors, toxic signals, competitors, gaps, and disavow candidates. Use only when links or referring domains are the requested focus." |
| core-seo | seo-cluster | "Cluster keywords by SERP overlap and design hub-and-spoke content architecture with internal links. Use for planning; `/seo cluster execute` then writes the posts with claude-blog |
| core-seo | seo-competitor-pages | "Generate SEO-optimized competitor comparison and alternatives pages. Covers \"X vs Y\" layouts, \"alternatives to X\" pages, feature matrices, schema markup, and conversion optimi |
| core-seo | seo-content-brief | "Generate competitive SEO content briefs with per-section word counts, competitor scoring, keyword placement guidance, and page-type templates. Supports both new page briefs and im |
| core-seo | seo-content | "Evaluate page content for usefulness, E-E-A-T, readability, thinness, and AI citation readiness, plus last-mile draft cleanup (AI-typical phrasing and invisible Unicode watermark  |
| core-seo | seo-ecommerce | "Analyze ecommerce SEO across product pages, product schema, Shopping visibility, marketplace signals, and keyword gaps. Use only for stores, catalogs, or product listings.\n" |
| core-seo | seo-flow | "FLOW framework integration: evidence-led SEO using the Find → Leverage → Optimize → Win loop. Surfaces stage-specific AI prompts from the FLOW knowledge base (41 prompts, CC |
| core-seo | seo-hreflang | "Hreflang and international SEO audit, validation, and generation. Detects common mistakes, validates language/region codes, and generates correct hreflang implementations. Use whe |
| core-seo | seo-images | "Image optimization analysis for SEO and performance. Checks alt text, file sizes, formats, responsive images, lazy loading, CLS prevention, image SERP rankings (via DataForSEO), a |
| core-seo | seo-local | "Audit local SEO, including Google Business Profile, NAP consistency, citations, reviews, local schema, location pages, and multi-location structure. Use when the user asks about l |
| core-seo | seo-maps | "Maps intelligence for local SEO: geo-grid rank tracking, GBP profile auditing via API, review intelligence across Google/Tripadvisor/Trustpilot, cross-platform NAP verification, c |
| core-seo | seo-page | "Analyze one supplied URL across on-page, content, technical metadata, schema, images, and performance. Use only for a single-page review.\n" |
| core-seo | seo-plan | "Strategic SEO planning for new or existing websites. Industry-specific templates, competitive analysis, content strategy, and implementation roadmap. Use when user says \"SEO plan |
| core-seo | seo-programmatic | "Programmatic SEO planning and analysis for pages generated at scale from data sources. Covers template engines, URL patterns, internal linking automation, thin content safeguards, |
| core-seo | seo-schema | "Detect, validate, or generate Schema.org JSON-LD for a supplied page or entity. Use only when structured data or rich-result markup is requested.\n" |
| core-seo | seo-sitemap | "Analyze existing XML sitemaps or generate new ones with industry templates. Validates format, URLs, and structure. Use when user says \"sitemap\", \"generate sitemap\", \"sitemap  |
| core-seo | seo-sxo | "Diagnose search-experience and intent mismatches using SERP page types, user stories, and persona scoring. Use when ranking problems appear intent- or layout-driven.\n" |
| core-seo | seo-technical | "Audit technical SEO across crawlability, indexability, security, URLs, mobile, Core Web Vitals, rendering, structured data, and IndexNow. Use when the user asks for a technical SE |
| core-seo | seo | "Comprehensive SEO analysis for any website or business type. Full site audits, single-page analysis, technical SEO (crawlability, indexability, Core Web Vitals with INP), schema m |
| geo-aio | beyond-seo | Use for SEO audits, AEO/GEO strategy, local SEO, backlink review, competitor research, keyword mapping, Apify/native scraping workflows, and client-ready SEO reporting. |
| geo-aio | geo-optimizer | Audit and fix a website for AI search visibility (Generative Engine Optimization). Use when asked to check whether a site or page can be found and cited by ChatGPT Search, Perplexi |
| geo-aio | seo-agentic | "Audit and fix agent readiness: the Lighthouse Agentic Browsing fraction, accessibility tree for agents, robots.txt and Content-Signal for AI agents, WAF treatment of agent traffic |
| geo-aio | seo-geo | "Audit and improve content for AI Overviews and answer engines, including citability, entity clarity, crawler access, brand signals, and passage structure. Use when the user asks a |
| openseo | openseo-ai-prompt-research | Find the questions people ask about a market, how ChatGPT answers them, and which sites get cited in the answers. Use when the user asks what people ask AI about their niche, wants |
| openseo | openseo-ai-visibility-audit | Audit how a brand shows up in AI answers about its market and deliver a short report on the few changes most likely to get it mentioned or cited, such as a third-party page to get  |
| openseo | openseo-competitive-landscape | Map SEO market leaders, winning content themes, keyword coverage, backlinks, and strategic gaps. |
| openseo | openseo-competitor-analysis | "Analyze one competitor's organic footprint, ranking keywords, content themes, backlinks, and gaps." |
| openseo | openseo-keyword-clustering | Cluster keywords by intent and map them to existing or proposed pages. |
| openseo | openseo-keyword-research | "Discover keyword opportunities, evaluate metrics and SERPs, and save/tag promising terms." |
| openseo | openseo-link-prospecting | Find link prospects, discover contact paths, and draft outreach from SERPs and backlink signals. |
| openseo | openseo-local-seo | "Audit a Google Business Profile, compare it to local competitors, and map Maps visibility around a location." |
| openseo | openseo-seo-audit | "Audit a website, investigate its real search opportunities, and deliver a short data-backed report on the few changes most likely to grow organic traffic that converts." |
| openseo | openseo-seo-coach | Enter a friendly OpenSEO coach mode that explains workflows, recommends next steps, and helps users use agents, web search, scraping, and MCP data effectively. |
| openseo | openseo-seo-project-setup | Populate a project's shared OpenSEO context — site scope, goals, positioning, competitors, key pages, and preferences — plus MCP checks and Search Console intake. |
| openseo | openseo-seo-report | "Write and save an OpenSEO report as one self-contained HTML page. Use when a skill has finished its research, and whenever the user asks for a report, check-in, or summary, or nam |
| plugins | marketing-seo-audit | Run a comprehensive SEO audit — keyword research, on-page analysis, content gaps, technical checks, and competitor comparison. Use when assessing a site's SEO health, when findin |
| plugins | small-business-seo-ai-visibility | "Audits and fixes both halves of being found — classic search and AI answers. Search side: rankings, site structure, page speed, titles and descriptions, and content that answers |
| plugins/youtube | yt-seo | Write the description, tags and search-facing text for a YouTube video, aimed at the query a real person types. Use for "write my description", "tags", "SEO", "help this video get  |
